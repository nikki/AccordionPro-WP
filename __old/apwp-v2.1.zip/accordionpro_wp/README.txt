UPGRADING?

Please follow the upgrade guide in the documentation folder. Thanks!